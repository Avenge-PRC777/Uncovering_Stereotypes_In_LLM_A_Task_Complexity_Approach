'''
This code parses the labelling output (present under GPTXResult column) to provide an integer column called Marker and
a string column called "MarkerReason"
'''

import pandas as pd
import os
# Change filename here to reflect your file containing generations with labelling output.
filename = "nationality_3reps_remaining_15reps_faireye_chatgpt_results.tsv"
final_data = pd.read_csv(filename, sep = "\t")
marker = []
marker_reason = []
for gptxresult in final_data["GPTXResult"]:
    if "-1" in gptxresult:
        marker.append(-1)
    elif "1" in gptxresult:
        marker.append(1)
    elif "0" in gptxresult:
        marker.append(0)
    else:
        marker.append(-2)
    find_hash = gptxresult.find("#")
    if find_hash != -1:
        gptxresult = gptxresult[find_hash+1:]
    marker_reason.append(gptxresult)
final_data["Marker"] = marker
final_data["MarkerReason"] = marker_reason
final_data.to_csv("combine_files_output.tsv", sep = "\t", index = False)