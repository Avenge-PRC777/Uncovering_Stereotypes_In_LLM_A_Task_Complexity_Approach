'''
This code corrects labelling precision for identifier 6 type prompt
'''

import pandas as pd

data = pd.read_csv("combine_files_output.tsv", sep = "\t")

mask = (data["Identifier"] == 6)
data_sub = data[mask]

data_sep = data[~mask]


print(len(data_sub))
print(len(data_sep))
print(len(data))

corrected_markers = []
correction_done = []
for gs, bs, answer,og_marker in zip(data_sub["gs"],data_sub["bs"],data_sub["answer"],data_sub["Marker"]):
    if gs.lower() in answer.lower():
        corrected_markers.append(1)
        correction_done.append(1)
    elif bs.lower() in answer.lower():
        corrected_markers.append(0)
        correction_done.append(1)
    else:
        corrected_markers.append(og_marker)
        correction_done.append(0)
data_sub["Marker_Corrected"] = corrected_markers
data_sub["Correction_Done"] = correction_done
print(len(data_sub))
data_sep["Marker_Corrected"] = data_sep["Marker"]
data_sep["Correction_Done"] = [0]*len(data_sep)

data_final = pd.concat([data_sep, data_sub])
print(len(data_final))
data_final.to_csv("combine_files_output_corrected_for_6.tsv", sep = "\t", index = False)