import pandas as pd
import json
data = pd.read_csv("combine_files_output_corrected_for_6.tsv", sep = "\t")
mapping = json.loads(open("v2_true_country_to_continent_map.json", "r", encoding = "utf-8").read().strip())
continents = []
for country in data["nation_placeholder"]:
    if country in mapping:
        continents.append(mapping[country])
    else:
        continents.append("DoesNotApply")
data["Continent"] = continents
data.to_csv("combine_files_output_corrected_for_6_added_continent.tsv", sep = "\t", index = False)