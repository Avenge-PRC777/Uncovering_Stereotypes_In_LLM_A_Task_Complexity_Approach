from transformers import AutoTokenizer, pipeline, logging
from auto_gptq import AutoGPTQForCausalLM, BaseQuantizeConfig
import argparse
import pandas as pd
import time

model_name_or_path = "TheBloke/Llama-2-7b-Chat-GPTQ"
model_basename = "model"

use_triton = False

tokenizer = AutoTokenizer.from_pretrained(model_name_or_path, use_fast=True)
'''
model = AutoGPTQForCausalLM.from_quantized(model_name_or_path,
        model_basename=model_basename,
        use_safetensors=True,
        trust_remote_code=True,
        device="cuda:0",
        use_triton=use_triton,
        quantize_config=None)
'''
def run_interactive_mode():
  while True:
    input_str = input("Enter prompt (q|Q|quit to exit):")
    if input_str == "q" or input_str == "Q" or input_str == "quit":
      break
    input_ids = tokenizer(input_str, return_tensors='pt').input_ids.cuda()
    output = model.generate(inputs=input_ids, temperature=0.7, max_new_tokens=300)
    output_decoded = tokenizer.decode(output[0])
    output_str = output_decoded.replace("<s>","").replace("</s>","").replace(input_str,"").strip()
    print(output_str)

def run_batch_file_mode(args):
    model = AutoGPTQForCausalLM.from_quantized(model_name_or_path,
            model_basename=model_basename,
            use_safetensors=True,
            trust_remote_code=True,
            device=f"cuda:{args.gpu}",
            use_triton=use_triton,
            quantize_config=None)
    inp_data = pd.read_csv(f"input_{args.gpu+1}.tsv", sep = "\t")
    output_str_df = []
    output_index_df = []
    output_index = 0
    st = time.time()
    for query in inp_data["Query"]:
        print(output_index)
        try:
            input_ids = tokenizer(query, return_tensors='pt').input_ids.cuda()
            output = model.generate(inputs=input_ids, temperature=0.7, max_new_tokens=300)
            output_decoded = tokenizer.decode(output[0])
            output_str = output_decoded.replace("<s>","").replace("</s>","").replace(query,"").strip()
        except Exception as e:
            print(e)
            output_str = str(e)
        output_str_df.append(output_str.replace("\n","\\n").replace("\r","\\r"))
        output_index_df.append(output_index)
        output_index += 1
        open(f"temp_processed_input_{args.gpu+1}.tsv", "w", encoding = "utf-8").write("\n".join([str(a)+"\t"+b for a,b in zip(output_index_df, output_str_df)]))
    inp_data["Output"] = output_str_df
    inp_data["OutputIndex"] = output_index_df
    inp_data.to_csv(f"processed_input_{args.gpu+1}.tsv", sep = "\t", index = False)
    et = time.time()
    print(f"Time taken to complete: {et-st} seconds")

def main(args):
    if args.mode == "interactive":
        run_interactive_mode()
    elif args.mode == "batch_file":
        run_batch_file_mode(args)

if __name__ == "__main__":
  parser = argparse.ArgumentParser()
  #parser.add_argument("--model_name", default = "TheBloke/Llama-2-7b-Chat-GPTQ", type = str, required=False, help = "Model name to infer; Default is TheBloke/Llama-2-7b-Chat-GPTQ")
  parser.add_argument("--mode", default = "interactive", type = str, required=False, help = "mode is either interactive/bulk file")
  parser.add_argument("--gpu", default = 1, type = int, required=True)
  args = parser.parse_args()
  main(args)
