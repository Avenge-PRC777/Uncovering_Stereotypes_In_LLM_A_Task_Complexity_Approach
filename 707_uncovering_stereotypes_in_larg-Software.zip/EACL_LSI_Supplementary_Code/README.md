# USLLM code

The process is divided into 3 parts:
1. **s1_prompt_filling\\**: Creation of generation prompts by filling dynamic task based prompts with demography attributes and LSI stereotypes, the output of this stage is fed into model.
2. **s2_generation_pre_process_for_detection\\**: Creation of detection prompt by filling detection prompt with resultant generation from stage 1 and the LSI stereotypes, the output of this stage is fed into GPT-4 for detection/labelling.
3. **s3_process_detection\\**: Post processing the labelling and correction for task type identifier 6 (code based prompt) for analysis. The codes here modify the output of stage 2 by adding pivots to analyze.

# Getting started
1. For stage 1, user just needs to run **generate_filled_prompts.ipynb**
2. For stage 2, user just needs to run **create_detection_prompts_from_generations.py**
3. For stage 3, user needs to run **combine_files.py**, **combine_files_fix_identifier_6_minus1.py**, **combine_files_add_continents.py** in given order.

# LLaMA2-7B generations
The code used for generating LLaMA2-7B outputs is shared as a python script "llama2_7b_inference.py" in the directory "llama2_generation".