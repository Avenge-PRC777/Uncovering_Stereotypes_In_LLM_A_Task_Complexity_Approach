'''
This code takes the generation file and processes it to create detection prompts to detect if the generation had bias or not
'''

import pandas as pd

pattern_to_split_by = "<|im_end|>"
# Change below filename to the file containing generations from stage 1
filename = "4Categories_3reps_15reps_SPI_12_7Tasks_ID6Changed_ChatGPT_DV3_Generations.tsv"
data = pd.read_csv(filename, sep = "\t")
outfilename = filename[:-4]
print(len(data))
print(data.head())

gptxresults_formatted_for_bias_detection = []
# In this code, it is assumed the generations are present under "GPTXResult" column, the type of task is marked by "Identifier" column
# The original generation prompt is present under "query" column and the stereotypes are present under "GoodStereotype" and "BadStereotype" respectively.
for gptxresult, identifier, query, gs, bs in zip(data["GPTXResult"], data["Identifier"], data["query"], data["GoodStereotype"], data["BadStereotype"]):
    query = query.lower()
    gptxresult = gptxresult.lower()
    find_im_end = gptxresult.find(pattern_to_split_by)
    if find_im_end != -1:
        gptxresult = gptxresult[:find_im_end] # Trim till first "<|im_end|>" to avoid unnecessary context
    identifier = int(identifier)
    if identifier == 6:
        find_else = gptxresult.find("else")
        if find_else != -1:
            gptxresult = gptxresult[:find_else] # Trim everything after else to avoid unnecessary context that leads to wrong GPT results
    elif identifier == 1:
        gptxresult = gptxresult.replace("-","").replace("|","") # Replace the --------|---------- with space as it leads to wrong GPT results
    gptxresults_formatted_for_bias_detection.append(gptxresult)

data["answer"]=gptxresults_formatted_for_bias_detection
data.rename(columns = {"BadStereotype":"bs","GoodStereotype":"gs","query":"question"}, inplace = True)
data.drop(columns = ["GPTXResult"], inplace = True)
data.to_csv(f"{outfilename}_processed_for_detection.tsv", sep = "\t", index = False)