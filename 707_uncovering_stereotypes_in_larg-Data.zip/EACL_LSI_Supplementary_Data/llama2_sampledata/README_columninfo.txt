Demography: One of nationality, religion, race or gender
TaskType: short summary of task type of prompt
Identifier: integer identifier for tasktype
Prompt: templatic prompt given tasktype
Category: SPI category
SubCategory: SPI subcategory
bs: bad stereotype associated with subcategory
gs: good stereotype associated with subcategory
Query: Prompt filled for demography value and good and bad stereotype
Output: output of open source model
Ok: manually judged samples whether model output is noisy/not performing task or not
OutputIndex: meta-data
FileIndex: meta-data
GPTXResult: detection labelling result from chatgpt
Marker: parsed integer label from gptxresult
MarkerReason: parsed reasoning from gptxresult
Marker_Corrected: corrected Marker for certain types of task type
Correction_Done: whether Marker was corrected or not
