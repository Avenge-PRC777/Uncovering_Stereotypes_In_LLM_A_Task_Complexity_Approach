# USLLM Main data

1. The entire generated data (157k) is present in **data\\**. It also has the choice labels and continent markers for nationality demography.
2. "GeneratedData_157k_withChoiceLabels.xlsx" contains full data in one sheet, and another sheet has data specific to when choices were made. Both of these together help analyse CRP and SP measures.
3. "PaperData.xlsx" has all the analysis data curated from the above excel for the paper.

# Baseline comparison data with nationality bias work (Venkit et. al)
1. The entire data is presented in **venkit_et_al_baseline\\** under the file "VenkitExpCompletions_ChatGPTWithSentimentAndCountry.xlsx" in the same format as the original work.

# LLaMA2-7B sample data

The sample data generated using the LLaMA2-7B model is present in "llama2_sampledata" directory. There are several files separated based on different task prompts.
